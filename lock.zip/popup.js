document.getElementById('confirm').addEventListener('click', function () {
    const lockTab = document.getElementById('lockTab').checked;
    chrome.storage.local.set({ lockTab: lockTab }, function () {
        chrome.runtime.sendMessage({ lockTab: lockTab });
    });
});

chrome.storage.local.get(['lockTab'], function (items) {
    document.getElementById('lockTab').checked = items.lockTab || false;
});
