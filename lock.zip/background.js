chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    if (message.lockTab !== undefined) {
        chrome.storage.local.set({ lockTab: message.lockTab }, function () {
            applyLockState(message.lockTab);
        });
    }
});

chrome.storage.local.get(['lockTab'], function (items) {
    applyLockState(items.lockTab || false);
});

function applyLockState(isLocked) {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        if (tabs[0]) {
            const code = isLocked ? `
                window.addEventListener("beforeunload", function (e) {
                    var confirmationMessage = "Are you sure you want to leave?";
                    (e || window.event).returnValue = confirmationMessage;
                    return confirmationMessage;
                });
            ` : `
                window.removeEventListener("beforeunload", function () {});
            `;
            chrome.tabs.executeScript(tabs[0].id, { code: code });
        }
    });
}
